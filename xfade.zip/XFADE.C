//////////////////////////////////////////////////////////////////////////////

/*
Cross(X)-Fade by Dark Fader

Description:
  2 full-screen fast swapping images to show GBC capabilities.
  Don't mention the stupid fading: It's more useful to use this as a backbuffer (for 3D etc..3-)
  Note that 'X' doesn't stand for 'cross' X-)

Minimal system requirements:
  * Powered GameBoy Color ;-O or compatible
  * Some ROM & RAM (To hold GBDK libraries + code;)

Notes:
  * Use GBDK bla-bla-17
  * MAKE dblspeed first
*/

#include <gb.h>
#include <stdio.h>
#include "dblspeed.h" // NOT needed, but funny
#include "map1.c"
#include "tiles1.c"
#include "map2.c"
#include "tiles2.c"

//////////////////////////////////////////////////////////////////////////////
// Inits 2 palettes
//////////////////////////////////////////////////////////////////////////////

#define RGB(r,g,b) ((r)*1 + (g)*32 + (b)*1024)

void InitPalettes()
{
  long red[4] = { RGB(31,0,0), RGB(20,0,0), RGB(12,0,0), RGB(0,0,0) }; // light->dark!
  long blue[4] = { RGB(0,0,31), RGB(0,0,20), RGB(0,0,12), RGB(0,0,0) };
  set_bkg_palette(7, 1, (void*)blue); // palette 0 (7)
  set_bkg_palette(6, 1, (void*)red); // palette 1 (6)
}

//////////////////////////////////////////////////////////////////////////////
// Loads 2 tilesets, 2 tilemaps & 2 attribute-maps
//////////////////////////////////////////////////////////////////////////////

void InitImages()
{
  VBK_REG = 0; // bank0
  set_bkg_tiles(0,0,20,18,Map1PLN0); // tilemap 1
  set_win_tiles(0,0,20,18,Map2PLN0); // tilemap 2
  set_data((void*)0x8000, Tiles1, 16*360); // tileset 1
  VBK_REG = 1; // bank1
  set_bkg_tiles(0,0,20,18,Map1PLN1); // attribute map 1
  set_win_tiles(0,0,20,18,Map2PLN1); // attribute map 2
  set_data((void*)0x8000, Tiles2, 16*360); // tileset 2
}

//////////////////////////////////////////////////////////////////////////////
// APA (All-Point-Addressable) mode stuff
//////////////////////////////////////////////////////////////////////////////

void Vbl() {
  LCDC_REG |= 0x10; // tileset shown on top part of LCD
  LY_REG = 0; // reset line counter, don't use blanking period
}

void Lcd()
{
  LCDC_REG &= 0xEF; // tileset shown on bottom part of LCD
}

void InitAPA()
{
  STAT_REG = 64;
  LYC_REG = SCREENHEIGHT/2;
  Add_VBL(Vbl);
  Add_LCD(Lcd);
  set_interrupts(VBL_IFLAG | LCD_IFLAG); 
  enable_interrupts();
  SHOW_BKG;
}

//////////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////////

char Fades[13][12] =
{
  0,0,0,0,0,0,0,0,0,0,0,0, // 0/12
  0,0,0,0,0,0,0,0,0,0,0,1, // 1/12
  0,0,0,0,0,1,0,0,0,0,0,1, // 2/12
  0,0,0,1,0,0,0,1,0,0,0,1, // 3/12
  0,0,1,0,0,1,0,0,1,0,0,1, // 4/12
  0,0,1,0,1,0,1,0,0,1,0,1, // 5/12
  0,1,0,1,0,1,0,1,0,1,0,1, // 6/12
  0,1,0,1,0,1,1,0,1,0,1,1, // 7/12
  0,1,1,0,1,1,0,1,1,0,1,1, // 8/12 
  0,1,1,1,0,1,1,1,0,1,1,1, // 9/12 
  0,1,1,1,1,1,0,1,1,1,1,1, // 10/12
  0,1,1,1,1,1,1,1,1,1,1,1, // 11/12
  1,1,1,1,1,1,1,1,1,1,1,1, // 12/12
};

void DoFade(int f)
{
  int fc;
  for (fc=0; fc<12; fc++) {
    if (Fades[f][fc]) {
      wait_vbl_done();
      LCDC_REG |= 0x08;
    } else {
      wait_vbl_done();
      LCDC_REG &= 0xF7;
    }
  }
}

void main()
{
  int f;
  if (!CurrentSpeed()) SwitchSpeed(); // double speed! (NOT needed for flipping one bit per VBL. Just 4 fun)
  InitPalettes();
  InitImages();
  InitAPA();
  while (1) {
    for (f=0; f<=12; f++) DoFade(f);
    for (f=11; f>=1; f--) DoFade(f);
  }
}

//////////////////////////////////////////////////////////////////////////////
