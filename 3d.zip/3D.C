#include <gb.h>

#include <drawing.h>
#include "dblspeed.h"
#include "sincos.h"
#include "cube.h"
#include "map1.h"
#include "map2.h"
#include "clrtiles.h"

// GBC palette definitions
#define CGBPAL(id,pal) id##CGBPal##pal##c0,id##CGBPal##pal##c1,id##CGBPal##pal##c2,id##CGBPal##pal##c3
#define CGBPALS(id) {CGBPAL(id,0),CGBPAL(id,1),CGBPAL(id,2),CGBPAL(id,3),CGBPAL(id,4),CGBPAL(id,5),CGBPAL(id,6),CGBPAL(id,7)}
UWORD palettes[] = CGBPALS(clrtiles);

// DMA: xxx0..xxx0 -> 8xx0..9xx0, size: 16..2048
#define HDMA(src,dest,size) \
  *(UBYTE*)0xFF51 = (src)>>8; \
  *(UBYTE*)0xFF52 = (src)&0xFF; \
  *(UBYTE*)0xFF53 = (dest)>>8; \
  *(UBYTE*)0xFF54 = (dest)&0xFF; \
  *(UBYTE*)0xFF55 = 128 + (size)/16-1;

// DMA: xxx0..xxx0 -> 8xx0..9xx0, size: 16..2048
#define GPDMA(src,dest,size) \
  *(UBYTE*)0xFF51 = (src)>>8; \
  *(UBYTE*)0xFF52 = (src)&0xFF; \
  *(UBYTE*)0xFF53 = (dest)>>8; \
  *(UBYTE*)0xFF54 = (dest)&0xFF; \
  *(UBYTE*)0xFF55 = (size)/16-1;

Point projected[VERTICES];

int cx,cy,cz,sx,sy,sz;

#define Sar(a,b) (((a)<0) ? -(-(a)>>(b)) : ((a)>>(b))) // shift ar. right
#define Mul(a,b) (long)(a)*(b)

long dist;

void RotateAndProject()
{
  int v;
  for (v=0; v<VERTICES; v++) {
	long x1,y1,z1;
	long xx,yy;
	long zz;
    x1 = Mul(cy, vertices[v][0]) - Mul(sy, vertices[v][2]);
    x1 = Sar(x1,7);
    z1 = Mul(sy, vertices[v][0]) + Mul(cy, vertices[v][2]);
    z1 = Sar(z1,7);
    xx = Mul(cz, x1            ) + Mul(sz, vertices[v][1]);
    xx = Sar(xx,7);
    y1 = Mul(cz, vertices[v][1]) - Mul(sz, x1            );    
	y1 = Sar(y1,7);
    yy = Mul(sx, z1            ) + Mul(cx, y1            );
    yy = Sar(yy,7);
    zz = Mul(cx, z1            ) - Mul(sx, y1            );
    zz = Sar(zz,7) + 256;
    zz += dist;
    projected[v][0] = 80 + Sar((xx * zz), 8);
    projected[v][1] = 72 + Sar((yy * zz), 8);
  }
}

void DrawLines()
{
  int l;  
  for (l=0; l<LINES-0; l++) {
  	int x1 = projected[lines[l][0]][0];
  	int y1 = projected[lines[l][0]][1];
  	int x2 = projected[lines[l][1]][0];
  	int y2 = projected[lines[l][1]][1];
  	if (y2<y1) { // swap points
  		int t;
  		t = x1; x1 = x2; x2 = t;
  		t = y1; y1 = y2; y2 = t;
  	}  	
    line(x1,y1,x2,y2);
  }
}

void Vbl() { LCDC_REG |= 0x10; }
void Lcd() { LCDC_REG &= 0xEF; }

void Init()
{
  char temp[18][20];
  
  if (!CurrentSpeed()) SwitchSpeed(); // double speed!

  mode(M_DRAWING);
  color(3, 3, SOLID);

  disable_interrupts();
  remove_irqs();
  STAT_REG = 64;
  LYC_REG = SCREENHEIGHT/2;
  Add_VBL(Vbl);
  Add_LCD(Lcd);
  set_interrupts(VBL_IFLAG | LCD_IFLAG); 
  enable_interrupts();

  set_bkg_palette(0, 8, palettes);
  VBK_REG = 1;
  set_bkg_tiles(0,0,20,18,map1PLN1); // attribute map to use VBK 0
  set_win_tiles(0,0,20,18,map2PLN1); // attribute map to use VBK 1
  VBK_REG = 0;
  get_bkg_tiles(0,0,20,18,(void*)temp); // copy bg tilemap
  set_win_tiles(0,0,20,18,(void*)temp); // to window tilemap
}

void main()
{
  int writebank=0;
  int rx=0, ry=0, rz=0;
  dist = 0;

  Init();
  SWITCH_ROM_MBC1(1);

  while (1) {
  	UBYTE joy = joypad();
  	if (joy & J_UP) rx-=1;
  	if (joy & J_DOWN) rx+=1;
  	if (joy & J_LEFT) ry+=1;
  	if (joy & J_RIGHT) ry-=1;
  	if (joy & J_SELECT) rz+=1;
  	if (joy & J_START) rz-=1;
  	if (joy & J_A) dist-=3;
  	if (joy & J_B) dist+=3;
//    rx+=1; ry+=2; rz+=2;
    
    cx = ctab[rx]; cy = ctab[ry]; cz = ctab[rz];
    sx = stab[rx]; sy = stab[ry]; sz = stab[rz];
    RotateAndProject();
    DrawLines();

	wait_vbl_done2();
    if ((VBK_REG = (writebank ^= 1)) != 0) LCDC_REG &= 0xF7; else LCDC_REG |= 0x08;
	GPDMA((long)clrtiles+0x100, 0x8000, 0x800);
	wait_vbl_done2();
	GPDMA((long)clrtiles+0x100, 0x8800, 0x800);
	HDMA((long)clrtiles+0x100, 0x9000, 0x680);
  }
}
