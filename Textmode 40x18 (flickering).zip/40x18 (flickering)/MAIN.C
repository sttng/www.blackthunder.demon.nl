//////////////////////////////////////////////////////////////////////////////
// main.c                                                                   //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include <gb.h>
#include "tiles.h"

//////////////////////////////////////////////////////////////////////////////
// defines                                                                  //
//////////////////////////////////////////////////////////////////////////////
#define CGBPAL(id,pal) id##CGBPal##pal##c0,id##CGBPal##pal##c1,id##CGBPal##pal##c2,id##CGBPal##pal##c3
#define CGBPALS(id) {CGBPAL(id,0),CGBPAL(id,1),CGBPAL(id,2),CGBPAL(id,3),CGBPAL(id,4),CGBPAL(id,5),CGBPAL(id,6),CGBPAL(id,7)}

//////////////////////////////////////////////////////////////////////////////
// variables                                                                //
//////////////////////////////////////////////////////////////////////////////
unsigned char empty[18][32];

//////////////////////////////////////////////////////////////////////////////
// Vbl_irq                                                                  //
//////////////////////////////////////////////////////////////////////////////
void Vbl_irq()
{
	static int frame;
	if (frame)
	{
		// odd
//		UWORD palettes[] = {RGB(31,31,31), RGB(16,16,16), RGB(0,0,0), RGB(31,31,31)};
		UWORD palettes[] = {RGB(0,0,0), RGB(16,16,16), RGB(31,31,31), RGB(0,0,0)};
		set_bkg_palette(0,1, palettes);
		LCDC_REG |= 0x08; // 0x9C00
		frame = 0;
	}
	else
	{
		// even
//		UWORD palettes[] = {RGB(31,31,31), RGB(16,16,16), RGB(31,31,31), RGB(0,0,0)};
		UWORD palettes[] = {RGB(0,0,0), RGB(16,16,16), RGB(0,0,0), RGB(31,31,31)};
		set_bkg_palette(0,1, palettes);
		LCDC_REG &=~ 0x08U; // 0x9800
		frame = 1;
	}
}

//////////////////////////////////////////////////////////////////////////////
// print                                                                    //
//////////////////////////////////////////////////////////////////////////////
void print(char *s)
{
	static unsigned int x,y;
	while (*s)
	{
		switch (*s)
		{
			case '\n':
				x=0; y++;
				break;
			
			case '^':
				x=0; y=0;
				break;
			
			default:
				//disable_interrupts();
				if (x >= 40) { x=0; y++; }
				if (x & 1)
					set_win_tiles(x>>1,y,1,1, (void*)s); // odd
				else
					set_bkg_tiles(x>>1,y,1,1, (void*)s); // even
				//enable_interrupts();
				x++;
				break;
		}
		s++;
	}
}

/////////////////////////////////////////////////////////////////////////////
// main                                                                     //
//////////////////////////////////////////////////////////////////////////////
void main()
{
	VBK_REG=1; set_bkg_tiles(0,0,32,18, (void*)empty);
	VBK_REG=0; set_bkg_tiles(0,0,32,18, (void*)empty);
	VBK_REG=1; set_win_tiles(0,0,32,18, (void*)empty);
	VBK_REG=0; set_win_tiles(0,0,32,18, (void*)empty);
	
	LCDC_REG &=~ 0x10U;
	set_bkg_data(0,128, tiles);

	disable_interrupts();
	
	IE_REG = VBL_IFLAG;

	print("^");

	print("Hello world!\n");
	print("This is mode 40x18. Don't pay attention\n");
	print("to the flickering because this is just\n");
	print("a simple method of doing it.\n");
	print("And doesn't see very pretty on emulators\n");

	print("Hello world!\n");
	print("This is mode 40x18. Don't pay attention\n");
	print("to the flickering because this is just\n");
	print("a simple method of doing it.\n");
	print("And doesn't see very pretty on emulators\n");

	print("Hello world!\n");
	print("This is mode 40x18. Don't pay attention\n");
	print("to the flickering because this is just\n");
	print("a simple method of doing it.\n");
	print("And doesn't see very pretty on emulators\n");

	enable_interrupts();
	
	while (1)
	{
	}
}
