#include <gb.h>
#include <drawing.h>
#include "font.h"
#include "map.h"
#include "stdio.h"

UWORD palette[] = {RGB(31,31,31), RGB(31,31,31), RGB(31,31,31), RGB(0,0,0)};

void main()
{
	set_bkg_palette(0, 1, palette);
	VBK_REG = 1; set_bkg_tiles(0,0,20,18,mapPLN1);
	VBK_REG = 0; set_bkg_tiles(0,0,20,18,mapPLN0);
	LCDC_REG |= 0x10;
	SHOW_BKG;

	printf2("From: DarkFader@gnn-nl.demon.nl\n");
	printf2("Date: friday 7 may 1999 23:50\n");
	printf2("Subject: 40x24 gameboy font\n");
	printf2("________________________________________\n");
	printf2("Hi everyone,\n");
	printf2("\n");
	printf2("This textmode 40x24 with a fontsize of\n");
	printf2("4x6 should be readable on a GBC.\n");
	printf2("(and the only system it runs on)\n");
	printf2("\n");
	printf2("Fast smooth scrolling and a blinking\n");
	printf2("cursor will be added soon.\n");
	printf2("And maybe some smoother font ;-)\n");
	printf2("(subpixeling)\n");
	printf2("\n");
	printf2("A text editor would be a great idea.\n");
	printf2("\n");
	printf2("I hope the speed it good enough for you.");
	printf2("Press the START button to see the speed.");
	printf2("\n");
	printf2("cya,\n");
	printf2("Dark Fader\n");

	while (!(joypad() & J_START));
	
	while (1) {
		printf2("Hello GameBoy developers on the world...");
		printf2("This is a speed-test of print2() in text");
		printf2("-mode 40x24 giving 2.67 times more space");
		printf2("than 20x18. Now running on a GBC at 1MHz");
		printf2("----------------------------------------");
	}
}


