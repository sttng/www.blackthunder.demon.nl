#ifndef _STDIO_H
#define _STDIO_H

void FntPrint(char x, char y, char c);
void putchar2(char c);
void print2(char *s);
void printn2(int value, int base, char sign);
void printf2(char *fmt, ...);

#endif
