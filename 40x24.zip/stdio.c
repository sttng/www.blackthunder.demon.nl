#include <stdio.h>
#include <stdarg.h>

int x, y;

void NewLine()
{
	x = 0;
	if (++y >= 24) y = 0;
}

void putchar2(char c)
{
	if (c == 10) { NewLine(); return; }
	FntPrint(x,y,c);
	if (++x >= 40) NewLine();
}

void print2(char *s)
{
	while (*s) putchar2(*s++);
}

void printn2(int value, int base, char sign)
{
	char table[] = "0123456789ABCDEF";
	do {
		putchar2(*table + (value % base));
		value /= base;
	} while (value > 0);
}

void printf2(char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	for (; *fmt; fmt++)
	{
		if (*fmt == '%')
		{
      		switch(*++fmt)
      		{
      			case 'c': // char
					putchar2(va_arg(ap, char));
					break;
      			case 'd': // decimal int
					printn2(va_arg(ap, int), 10, 1);
					break;
      			case 'u': // unsigned int
					printn2(va_arg(ap, int), 10, 0);
					break;
      			case 'x': // hexadecimal int
					printn2(va_arg(ap, int), 16, 0);
					break;
      			case 's': // string
					print2(va_arg(ap, char *));
					break;
      			case '%': // %
					putchar2('%');
					break;
			} // switch
		} else // if
			putchar2(*fmt);
	}
	va_end(ap);
}
