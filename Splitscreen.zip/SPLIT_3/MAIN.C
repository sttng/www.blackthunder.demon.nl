//////////////////////////////////////////////////////////////////////////////
// main.c                                                                   //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include <gb.h>
#include "tiles.h"
#include "bkg.h"
#include "wnd.h"

void Do();

void A()
{
	LCDC_REG = 0x81;
	SCX_REG = 0;
}

void B()
{
	LCDC_REG = 0xE1;
	SCX_REG = 160;
	WX_REG = 7+8*8;
	WY_REG = 1;
}

void C()
{
	LCDC_REG = 0xE9;
	SCX_REG = 96;
	HIDE_WIN;
}

//////////////////////////////////////////////////////////////////////////////
// main                                                                     //
//////////////////////////////////////////////////////////////////////////////
void main()
{
	cgb_compatibility();
	cpu_fast();
	
	VBK_REG=0;
	set_bkg_data(0,0, tiles);
	set_bkg_tiles(0,0,32,32, bkg);
	set_win_tiles(0,0,32,32, wnd);
	SHOW_BKG;
	
	STAT_REG = 8;			// irq on mode 0
	set_interrupts(LCD_IFLAG | VBL_IFLAG);
	
	Do();
}
