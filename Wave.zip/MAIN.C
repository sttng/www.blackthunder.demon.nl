//////////////////////////////////////////////////////////////////////////////
// MAIN.C                                                                   //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include <gb.h>
#include "tiles.h"
#include "map.h"
#include "sincos.h"

//////////////////////////////////////////////////////////////////////////////
// defines                                                                  //
//////////////////////////////////////////////////////////////////////////////
// GBC palette definitions
#define CGBPAL(id,pal) id##CGBPal##pal##c0,id##CGBPal##pal##c1,id##CGBPal##pal##c2,id##CGBPal##pal##c3
#define CGBPALS(id) {CGBPAL(id,0),CGBPAL(id,1),CGBPAL(id,2),CGBPAL(id,3),CGBPAL(id,4),CGBPAL(id,5),CGBPAL(id,6),CGBPAL(id,7)}

//////////////////////////////////////////////////////////////////////////////
// variables                                                                //
//////////////////////////////////////////////////////////////////////////////
UWORD palettes[] = CGBPALS(tiles);

//////////////////////////////////////////////////////////////////////////////
// VBL_Irq                                                                  //
//////////////////////////////////////////////////////////////////////////////
void VBL_Irq()
{
	//LCDC_REG |= 0x10;
	LYC_REG = 0;
}

//////////////////////////////////////////////////////////////////////////////
// LCD_Irq                                                                  //
//////////////////////////////////////////////////////////////////////////////
void LCD_Irq()
{
	static unsigned long i;
	SCX_REG = (stab[((LY_REG>>1) + (i>>3))&0xFF] >> 2);
	SCY_REG = (ctab[((LY_REG>>1) + (i>>4))&0xFF] >> 2) + 24;
	if (LY_REG < 144)
	{
		if (LY_REG < 96-SCY_REG)
			LCDC_REG |= 0x10;
		else
			LCDC_REG &= 0xEF;
	}
	i++;
	LYC_REG = LY_REG+1;
}

//////////////////////////////////////////////////////////////////////////////
// main                                                                     //
//////////////////////////////////////////////////////////////////////////////
void main()
{
	set_bkg_palette(0,8,palettes);

	VBK_REG = 0; set_bkg_tiles(0,0,32,24, mapPLN0);
	VBK_REG = 1; set_bkg_tiles(0,0,32,24, mapPLN1);
	
	VBK_REG = 0; set_data((void*)0x8000,tilesBLK0,0x800);
	VBK_REG = 1; set_data((void*)0x8000,tilesBLK1,0x800);
	VBK_REG = 0; set_data((void*)0x8800,tilesBLK2,0x800);
	VBK_REG = 1; set_data((void*)0x8800,tilesBLK3,0x800);
	VBK_REG = 0; set_data((void*)0x9000,tilesBLK4,0x800);
	VBK_REG = 1; set_data((void*)0x9000,tilesBLK5,0x800);

	SHOW_BKG;
	
	STAT_REG = 0x40;	// irq on LYC
	LYC_REG = 0;

	add_vbl(VBL_Irq);
	add_lcd(LCD_Irq);
	set_interrupts(VBL_IFLAG | LCD_IFLAG);
}
