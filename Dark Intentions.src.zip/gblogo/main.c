//////////////////////////////////////////////////////////////////////////////
// main.c                                                                   //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include "common.h"

//////////////////////////////////////////////////////////////////////////////
// variables                                                                //
//////////////////////////////////////////////////////////////////////////////
extern u8 gblogoBG0[];
extern u8 gblogoBG1[];
extern u8 gblogoMAPBG[];
extern u8 gblogoMAPABG[];
extern u16 gblogoBCPD[];
//const static u16 gblogo_pals[] = CGBPALS(gblogo_t);

//////////////////////////////////////////////////////////////////////////////
// main                                                                     //
//////////////////////////////////////////////////////////////////////////////
void GBLogo_main()
{
	u8 i;

	VBK_REG = 0;
	DecompressBG(gblogoBG0);
	set_bkg_tiles(0,0,20,18, gblogoMAPBG);
	VBK_REG = 1;
	set_bkg_tiles(0,0,20,18, gblogoMAPABG);
	set_bkg_palette(0,8, gblogoBCPD);
	
	/*set_bkg_palette(0, 8, (u16*)gblogo_pals);
	set_bkg_data2(128, 55, (u8*)gblogo_t);
	VBK_REG=1; set_bkg_tiles(0,0, 20,18, (u8*)gblogo_mPLN1);
	VBK_REG=0; set_bkg_tiles(0,0, 20,18, (u8*)gblogo_mPLN0);*/
	
	DISPLAY_ON;
	
	VBK_REG=1;
	for (i=0; i<26; i++)
	{
		set_bkg_tiles(0,6, 20,1, gblogoMAPABG + 18*20L + 23 - i);
		set_bkg_tiles(0,7, 20,1, gblogoMAPABG + 18*20L + 23 - i);
		set_bkg_tiles(0,8, 20,1, gblogoMAPABG + 18*20L + 23 - i);
		delay(50);
	}

	NR50_REG = 0x77;
	NR51_REG = 0xF3;
	NR52_REG = 0xF1;
	
	NR10_REG = 0x80;
	NR11_REG = 0xBF;
	NR12_REG = 0xF3;
	NR13_REG =  0x80;
	NR14_REG = 0xBF;
	delay(150);
	NR10_REG = 0x80;
	NR11_REG = 0xBF;
	NR12_REG = 0xF3;
	NR13_REG =  0xC1;
	NR14_REG = 0xBF;
}
