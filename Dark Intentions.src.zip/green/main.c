//////////////////////////////////////////////////////////////////////////////
// main.c                                                                   //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include "common.h"

//////////////////////////////////////////////////////////////////////////////
// variables                                                                //
//////////////////////////////////////////////////////////////////////////////
extern u8 greenBG0[];
extern u8 greenBG1[];
extern u8 greenMAPBG[];
extern u8 greenMAPABG[];
extern u16 greenBCPD[];

const static u8 scroll_text[] = "                    "
	"Hi all! This demo called \"Dark Intensions\" was made by Dark Fader... Greetings to "
	"Dox, Danzig, NE7, Quang, Jeff, Sasq, Vodka, Laxity, Shining, Lemon, Wooden Spoon, Martin, Danzig, Megaman_X, David, Pacman, GeeBee, Jarvik7, SMN, MMR, Xenocide, Xagor, Tribe, BRP, WebDreamer, Anarko, Fraktal, AARONSTJ, Moth3r, "
	"........ In order of randomness ;)"
	"                      ";

//////////////////////////////////////////////////////////////////////////////
// lcd_irq                                                                  //
//////////////////////////////////////////////////////////////////////////////
static void lcd_irq()
{
	if (LY_REG >= 144) return;
	
	BCPS_REG = 0x80;
	BCPD_REG = RGB(0,0,0);
	BCPD_REG = ((15 - (LY_REG>>4)) << 2);
	
	//LYC_REG = LY_REG+1;
}

//////////////////////////////////////////////////////////////////////////////
// vbl_irq                                                                  //
//////////////////////////////////////////////////////////////////////////////
static void vbl_irq()
{
	RefreshOAM();
	enable_interrupts();
	vbls++;
	UpdateScroller();
}

//////////////////////////////////////////////////////////////////////////////
// main                                                                     //
//////////////////////////////////////////////////////////////////////////////
void Green_main()
{
	VBK_REG = 0;
	DecompressBG(greenBG0);
	set_bkg_tiles(0,0,20,18, greenMAPBG);
	VBK_REG = 1;
	DecompressBG(greenBG1);
	set_bkg_tiles(0,0,20,18,greenMAPABG);
	set_bkg_palette(0,8, greenBCPD);

	LoadFontAsSprites();
	set_sprite_palette(0,8, (u16*)scroller_pals);
	
	add_VBL(vbl_irq);
	add_LCD(lcd_irq);
	STAT_REG = 8; // LYC_REG = 0;
	SHOW_SPRITES;
	DISPLAY_ON;
	
	
	SetScrollerText(scroll_text);

	while (!ScrollerDone());
}
