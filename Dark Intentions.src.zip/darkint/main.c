//////////////////////////////////////////////////////////////////////////////
// main.c                                                                   //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include "common.h"

//////////////////////////////////////////////////////////////////////////////
// variables                                                                //
//////////////////////////////////////////////////////////////////////////////
extern u8 darkintBG0[];
extern u8 darkintMAPBG[];
extern u8 darkintMAPABG[];
extern u16 darkintBCPD[];

//const static UWORD bkg_pals[] = CGBPALS(darkint_t);
static u8 x;
static u8 dir;
static s8 reveal;

//////////////////////////////////////////////////////////////////////////////
// lcd_irq                                                                  //
//////////////////////////////////////////////////////////////////////////////
void lcd_irq()
{
	//SCY_REG = (u16)LY_REG*(32-reveal)/16;	//LY_REG;// * reveal;
	
	if (LY_REG < 2*8)
	{
		SCY_REG = 0;
	}
	else if (LY_REG >= 10*8)
	{
		SCY_REG = 0;
	}
	else if (LY_REG < 6*8)
	{
		u8 y = LY_REG-(2*8);
		if (y+reveal >= 30)
			SCY_REG = 0-LY_REG;	// black
		else
			SCY_REG = (u16)y*reveal>>4;
	}
	else
	{
		u8 y = LY_REG-(6*8);
		if (y+reveal >= 30)
			SCY_REG = 0-LY_REG;	// black
		else
			SCY_REG = (u16)y*reveal>>4;
	}
	
	//LYC_REG = LY_REG+1;
}

//////////////////////////////////////////////////////////////////////////////
// vbl_irq                                                                  //
//////////////////////////////////////////////////////////////////////////////
static void vbl_irq()
{
	vbls++;
	//LYC_REG = 0;
	enable_interrupts();
	if (vbls&1)
	{
		if (dir) x--; else x++;
		if (x == 0) dir = 0;
		if (x == 20) dir = 1;
		VBK_REG=1;
		set_bkg_tiles(5,12, 10,1, darkintMAPABG + (20*12L-5) + x);
		set_bkg_tiles(5,13, 10,1, darkintMAPABG + (20*13L-5) + x);
		set_bkg_tiles(5,14, 10,1, darkintMAPABG + (20*14L-5) + x);
	}
}

//////////////////////////////////////////////////////////////////////////////
// main                                                                     //
//////////////////////////////////////////////////////////////////////////////
void DarkInt_main()
{
	VBK_REG=0;
	DecompressBG(darkintBG0);
	set_bkg_tiles(0,0, 20,18, darkintMAPBG);
	VBK_REG=1;
	//DecompressBG(darkintBG1);
	set_bkg_tiles(0,0, 20,18, darkintMAPABG);
	set_bkg_palette(0, 8, darkintBCPD);
	
	STAT_REG = 8;//64;
	reveal = 16;
	add_VBL(vbl_irq);
	add_LCD(lcd_irq);
	DISPLAY_ON;

	delay(500);
	while (reveal > -3) { reveal--; delay(50); }

	//while (1)
	{
		/*u8 i;
		FadeInit((u16*)bkg_pals);
		for (i=0; i<32; i++)
		{
			Fade();
			delay(200);
		}*/
	}

	delay(3000);
}
