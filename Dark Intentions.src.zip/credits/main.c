//////////////////////////////////////////////////////////////////////////////
// main.c                                                                   //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include "common.h"

//////////////////////////////////////////////////////////////////////////////
// variables                                                                //
//////////////////////////////////////////////////////////////////////////////
extern u8 starOBJ0[];
extern u16 starOCPD[];

extern u8 credits_text[];
extern u8 oam1[];
extern u8 oam2[];
extern u8 tilemap2[];
extern u8 attrmap2[];

const static UWORD bkg_pals[] =
{
	RGB(0,0,0), RGB( 7,  7, 7), RGB(12, 12,12), RGB(16, 16,16),	// r G B
	RGB(0,0,0), RGB( 9, 10,10), RGB(13, 16,16), RGB(21, 24,24),
	RGB(0,0,0), RGB(11, 13,13), RGB(18, 22,22), RGB(23, 28,28),
	RGB(0,0,0), RGB(13, 18,18), RGB(22, 27,27), RGB(24, 31,31),

	RGB(0,0,0), RGB( 7,  7, 7), RGB(12, 12,12), RGB(16, 16,16),	// R g b
	RGB(0,0,0), RGB(10,  9, 9), RGB(16, 13,13), RGB(24, 21,21),
	RGB(0,0,0), RGB(13, 11,11), RGB(22, 18,18), RGB(28, 23,23),
	RGB(0,0,0), RGB(18, 13,13), RGB(27, 22,22), RGB(31, 24,24),
};

//const static u16 sprite_pals[] = CGBPALS(sprtiles_t);
static u8 *text_ptr;
static u8 y;
static u8 updates;
static u8 pal;
static u8 *oam;

//////////////////////////////////////////////////////////////////////////////
// prototypes                                                               //
//////////////////////////////////////////////////////////////////////////////
void Scanmap(u8 c);

//////////////////////////////////////////////////////////////////////////////
// DoSprite                                                                 //
//////////////////////////////////////////////////////////////////////////////
void DoSprite(u8 i)
{
	s8 x,y;
	u16 z;
	u8 b = (u8)vbls + (i<<3);
	z = 64 + (s8)(u8)(b<<2);
	b += vbls;
	x = ((stab[b]*z)>>8) + 80;
	y = ((ctab[b]*z)>>8) + 80;
	*oam++ = y;
	*oam++ = x;
	*oam++ = 0+(y&1?4:0);
	*oam++ = pal;
	*oam++ = y;
	*oam++ = x+8;
	*oam++ = 2+(y&1?4:0);
	*oam++ = pal++; if (pal == 3) pal=0;
}

//////////////////////////////////////////////////////////////////////////////
// vbl_irq                                                                  //
//////////////////////////////////////////////////////////////////////////////
static void vbl_irq()
{
	RefreshOAM();
	enable_interrupts();
	vbls++;
	
	if (vbls & 1) OAM_SRC = 0xDD; else OAM_SRC = 0xDE;
	
	if (vbls & 1)
	{
		u8 i;
		oam = oam2;
		for (i=0; i<32; i+=2) DoSprite(i);
	}
	else
	{
		u8 i;
		oam = oam1;
		for (i=1; i<32; i+=2) DoSprite(i);
	}

	if (!text_ptr) return;
	if (vbls & 1) SCY_REG++;
	if (vbls & 3) return;

	if ((SCY_REG & 15) == 0)
	{
		//u8 tmp[64];
		u8 i, l = *text_ptr++;			// length
		u8 *a = tilemap2 + ((u16)y<<5);
		u8 *b = tilemap2 + ((u16)(y+1)<<5);
		u8 i2 = (20-l)>>1;
		
		if (l == 255) { text_ptr=0; return; }
		
		for (i=0; i<i2; i++) *a++ = *b++ = 0;
		i2 += l;
		for (; i<i2; i++)
		{
			u8 t = *text_ptr++ << 1;
			*a++ = t;
			*b++ = t+1;
		}
		for (; i<20; i++) *a++ = *b++ = 0;
		
		VBK_REG=0;
		set_bkg_tiles(0,y,64,1, tilemap2 + ((u16)y<<5));
		//set_bkg_tiles(0,y++,20,1, tmp+32);
		//HDMA(tilemap2 + ((u16)y<<5), 0x9800 + ((u16)y<<5), 64);
		
		y += 2;
		if (y >= 32) y=0;
	}
}

//////////////////////////////////////////////////////////////////////////////
// main                                                                     //
//////////////////////////////////////////////////////////////////////////////
void Credits_main()
{
	//u8 i;
	u8 sync=0;
	
	VBK_REG = 0;
	DecompressOBJ(starOBJ0);
	set_sprite_palette(0,8, starOCPD);
	
	set_bkg_palette(0, 8, (u16*)bkg_pals);
	LoadFontAsBackground();
	
 	y = 20;
 	text_ptr = credits_text;

	memset(tilemap2, 0x00, 32*32L);
	memset(attrmap2, 0x80, 32*32L);

	add_VBL(vbl_irq);
	SHOW_BKG;
	SHOW_SPRITES;
	DISPLAY_ON;
		
	while (text_ptr)
	{
		//updates++;
		
		if (sync_flip != sync)
		{
			sync = sync_flip;
			ScanMap(rand() & 0x0E);
		}
		else
		{
			Scanmap(255);	// none
		}
		
		/*
		if ((updates & 7) == 0)
		{
			ScanMap(rand() & 0x0E);
		}
		else
		{
			Scanmap(255);	// none
		}
		
		*/
		
		//VBK_REG=1;
		//HDMA(0x9800, attrmap2, 32*20L);

		//disable_interrupts();		// !!!!!!!!!!
		VBK_REG=1;
		HDMA(attrmap2, 0x9800, 32*32L);
		//enable_interrupts();
		
		delay(50);


		//delay(10);
	}
	

	// fade out
	for (y=0; y<4; y++)
	{
		Scanmap(255);
		VBK_REG=1;
		HDMA(attrmap2, 0x9800, 32*32L);
		delay(50);
	}

	// hide sprites
	HIDE_SPRITES;
	delay(5000);
}
