//////////////////////////////////////////////////////////////////////////////
// xlat.cpp                                                                 //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <conio.h>
#include <string.h>

//////////////////////////////////////////////////////////////////////////////
// main                                                                     //
//////////////////////////////////////////////////////////////////////////////
void main(int argc, char *argv[])
{
	if (argc < 2) { printf("Syntax: %1 <in.txt> <out.bin>\n", argv[0]); return; }

	FILE *fi = fopen(argv[1], "rt");
	if (!fi) { printf("Error opening input file!\n"); return; }
	FILE *fo = fopen(argv[2], "wb");
	if (!fo) { printf("Error opening output file!\n"); return; }

	while (1)
	{
		char s[256];
		if (!fgets(s, 256, fi)) break;

		// remove eol
		char *p = strchr(s, '\n');
		if (p) *p = 0;

		unsigned char tiles[2][32];
		memset(tiles, 0, sizeof(tiles));

		int len = strlen(s);
		fwrite(&len, 1, 1, fo);
		fwrite(s, len, 1, fo);
	}

	int end = 255;
	fwrite(&end, 1, 1, fo);

	fclose(fi);
	fclose(fo);
}
