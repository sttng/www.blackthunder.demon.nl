//////////////////////////////////////////////////////////////////////////////
// main.c                                                                   //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include "common.h"

//////////////////////////////////////////////////////////////////////////////
// variables                                                                //
//////////////////////////////////////////////////////////////////////////////
u16 vbls;
u8 sync_flip;
//u16 fade_pal[8*4];
//u8 fade_rgb[8*4][3];
//u8 fades[32][3][2];		// rgb: value, mod
static u16 fade_pal[32];
u8 *scroll_text_ptr;
u8 scroll_pos, scroll_pos_to;
static u8 *oam;


const u16 scroller_pals[] =
{
	RGB(0,0,0), RGB(10,10,10), RGB(20,20,20), RGB(31,31,31),

	RGB(0,0,0), RGB(31,31,31), RGB(16,16,16), RGB(0,0,0),
	RGB(0,0,0), RGB(0,0,0),    RGB(16,16,16), RGB(31,31,31),

	/*RGB(0,0,0), RGB( 5, 0, 0), RGB(10, 5, 5), RGB(31,15,15),
	RGB(0,0,0), RGB( 5, 0, 0), RGB(10, 5, 5), RGB(31,15,15),
	RGB(0,0,0), RGB( 5, 0, 5), RGB(10, 5,10), RGB(31,15,31),
	RGB(0,0,0), RGB( 0, 0, 5), RGB( 5, 5,10), RGB(15,15,31),
	RGB(0,0,0), RGB( 0, 5, 5), RGB( 5,10,10), RGB(15,31,31),
	RGB(0,0,0), RGB( 0, 5, 0), RGB( 5,10, 5), RGB(15,31,15),
	RGB(0,0,0), RGB( 5, 5, 0), RGB(10,10, 5), RGB(31,31,15),*/
};

//////////////////////////////////////////////////////////////////////////////
// Common_main                                                              //
//////////////////////////////////////////////////////////////////////////////
void Common_main()
{
	cpu_fast();
}

//////////////////////////////////////////////////////////////////////////////
// ResetStuff                                                               //
//////////////////////////////////////////////////////////////////////////////
void ResetStuff()
{
	u8 i;
	clear_VBL_LCD();
	//clear_VBL(); clear_LCD();
	set_interrupts(VBL_IFLAG | LCD_IFLAG | TIM_IFLAG);
	DISPLAY_OFF;
	SHOW_BKG;	// bkg priority
	SPRITES_8x16;
	HIDE_SPRITES;
	SCX_REG = SCY_REG = 0;
	ClearMaps();
	for (i=0; i<40; i++) move_sprite(i,0,0);
	memset((u8*)0xD000, 0, 4096);
}

//////////////////////////////////////////////////////////////////////////////
// ClearMaps                                                                //
//////////////////////////////////////////////////////////////////////////////
void ClearMaps()
{
	VBK_REG=1; memset((u8*)0x9800, 0, 32*32L);
	VBK_REG=0; memset((u8*)0x9800, 0, 32*32L);
	/*u8 i, tmp[2][32];
	for (i=0; i<32; i++) { tmp[0][i] = 0; tmp[1][i] = 0x80; }
	for (i=0; i<32; i++)
	{
		VBK_REG=1; set_bkg_tiles(0,i, 32,1, tmp[1]);
		VBK_REG=0; set_bkg_tiles(0,i, 32,1, tmp[0]);
	}*/
}

//////////////////////////////////////////////////////////////////////////////
// DecompressBG                                                             //
//////////////////////////////////////////////////////////////////////////////
void DecompressBG(u8 *data)
{
	Decompress((u8*)0x8800, data);
}

//////////////////////////////////////////////////////////////////////////////
// DecompressOBJ                                                            //
//////////////////////////////////////////////////////////////////////////////
void DecompressOBJ(u8 *data)
{
	Decompress((u8*)0x8000, data);
}

//////////////////////////////////////////////////////////////////////////////
// LoadFontAsBackground                                                     //
//////////////////////////////////////////////////////////////////////////////
void LoadFontAsBackground()
{
	VBK_REG=0; Decompress((u8*)0x9000, fontOBJ0);
	VBK_REG=0; Decompress((u8*)0x8800, fontOBJ1);
}

//////////////////////////////////////////////////////////////////////////////
// LoadFontAsSprites                                                        //
//////////////////////////////////////////////////////////////////////////////
void LoadFontAsSprites()
{
	VBK_REG=0; Decompress((u8*)0x8000, fontOBJ0);
	VBK_REG=1; Decompress((u8*)0x8000, fontOBJ1);
}

//////////////////////////////////////////////////////////////////////////////
// SetScrollerText                                                          //
//////////////////////////////////////////////////////////////////////////////
void SetScrollerText(const u8 *scroll_text)
{
	scroll_text_ptr = (u8*)scroll_text;
	scroll_pos = 0;
	scroll_pos_to = 0;
}

//////////////////////////////////////////////////////////////////////////////
// UpdateScroller                                                           //
//////////////////////////////////////////////////////////////////////////////
void UpdateScroller()
{
	u8 i,x;
	u8 *text;
	u8 *oam_ptr = oam_table;
	if (!scroll_text_ptr) return;

	scroll_pos_to += 2;
	
	while (scroll_pos != scroll_pos_to)
	{	
		scroll_pos++;
		if ((scroll_pos&7) == 0) scroll_text_ptr++;
	}
	
	x = -(scroll_pos&7);
	text = scroll_text_ptr;

	// set sprites
	for (i=0; i<21; i++)
	{
		*oam_ptr++ = 80 + (stab[(x<<1)+scroll_pos]>>3);	// y
		*oam_ptr++ = (x+=8);	// x
		*oam_ptr++ = *text<<1 & 0x7F;
		*oam_ptr++ = (*text++&64) >> 3;
	}
	if (!*text) { scroll_text_ptr = 0; return; }
	//scroll_pos--;
}

//////////////////////////////////////////////////////////////////////////////
// UpdateScroller2                                                          //
//////////////////////////////////////////////////////////////////////////////
void UpdateScroller2(u8 *oam_ptr, u8 oam_nr)
{
	u8 i,x;//,p=1;
	u8 *text;
	//u8 *oam_ptr = oam_table;	//(u8*)0xFE00;//
	if (!scroll_text_ptr) return;
	
	if (oam_nr)
	{
		x = (scroll_pos&7)-8;
		text = scroll_text_ptr+1;
	}
	else
	{
		x = (scroll_pos&7)-16;
		text = scroll_text_ptr+0;
	}

	// set sprites
	for (i=0; i<11; i++)
	{
		*oam_ptr++ = 80 + ((x+scroll_pos+i)&7);
		*oam_ptr++ = (x+=16);
		*oam_ptr++ = *text<<1 & 0x7F;
		*oam_ptr++ = ((*text++&64) >> 3) + 1 + ((scroll_pos+i)&1);//(p++); if (p == 8) p=1;
		*text++;
	}
	if (!*text) { scroll_text_ptr = 0; return; }
	scroll_pos -= 1;
	if ((scroll_pos&7) == 7) scroll_text_ptr++;
	scroll_pos -= 1;
	if ((scroll_pos&7) == 7) scroll_text_ptr++;
}

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
/*void FadeInit(u16 *pal)
{
	u8 i;
	for (i=0; i<32; i++)
	{
		/*u8 r = *pal&31;		// red
		u8 g = *pal>>5&31;	// green
		u8 b = *pal>>10&31;	// blue
		
		fades[i][0][0] = 0;	// value=0
		fades[i][0][1] = 256/r;	// mod=256
		fades[i][1][0] = 0;	// value=0
		fades[i][1][1] = 256/g;	// mod=256
		fades[i][2][0] = 0;	// value=0
		fades[i][2][1] = 256/b;	// mod=256*/

/*		fade_pal[i] = 0;
	}
}

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
void Fade()
{
	u8 i;
	//u16 *f = fades;
	for (i=0; i<32; i++)
	{
		//fades[i][0][0] += 8;
		//fade_pal[i] |= 1;
		//if (fades[i][0][0] > fades[i][0][1]) { fades[i][0][0] -= fades[i][0][1]; fade_pal[i] += 1; }
		//if (fades[i][1][0] > fades[i][1][1]) { fades[i][1][0] -= fades[i][1][1]; fade_pal[i] += 1<<5; }
		//if (fades[i][2][0] > fades[i][2][1]) { fades[i][2][0] -= fades[i][2][1]; fade_pal[i] += 1<<10; }	
	}
	//set_bkg_palette(0,8,fade_pal);
}
*/