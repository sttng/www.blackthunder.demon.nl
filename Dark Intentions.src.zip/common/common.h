//////////////////////////////////////////////////////////////////////////////
// common.h                                                                 //
//////////////////////////////////////////////////////////////////////////////
#ifndef _COMMON_H
#define _COMMON_H

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include <gb.h>
#include <string.h>
#include <rand.h>

//////////////////////////////////////////////////////////////////////////////
// types                                                                    //
//////////////////////////////////////////////////////////////////////////////
typedef unsigned char	u8;
typedef signed char		s8;
typedef UINT16	u16;
typedef INT16	s16;
typedef UINT32	u32;
typedef INT32	s32;

//////////////////////////////////////////////////////////////////////////////
// defines                                                                  //
//////////////////////////////////////////////////////////////////////////////
#define OAM_SRC	(*(u8*)0xFF81)		// high byte of address

// GBC palette definitions
#define CGBPAL(id,pal) id##CGBPal##pal##c0,id##CGBPal##pal##c1,id##CGBPal##pal##c2,id##CGBPal##pal##c3
#define CGBPALS(id) {CGBPAL(id,0),CGBPAL(id,1),CGBPAL(id,2),CGBPAL(id,3),CGBPAL(id,4),CGBPAL(id,5),CGBPAL(id,6),CGBPAL(id,7)}

// DMA: xxx0..xxx0 -> 8xx0..9xx0, size: 16..2048
//void HDMA(u8 *src, u8 *dest, u16 size);

// DMA: xxx0..xxx0 -> 8xx0..9xx0, size: 16..2048
//void GPDMA(u8 *src, u8 *dest, u16 size);

// DMA: xxx0..xxx0 -> 8xx0..9xx0, size: 16..2048
#define HDMA(src,dest,size) \
	HDMA1_REG = (u16)(src)>>8; \
	HDMA2_REG = (u16)(src)&0xFF; \
	HDMA3_REG = (u16)(dest)>>8; \
	HDMA4_REG = (u16)(dest)&0xFF; \
	HDMA5_REG = ((u16)(size)>>4) + 127;

// DMA: xxx0..xxx0 -> 8xx0..9xx0, size: 16..2048
#define GPDMA(src,dest,size) \
	HDMA1_REG = (u16)(src)>>8; \
	HDMA2_REG = (u16)(src); \
	HDMA3_REG = (u16)(dest)>>8; \
	HDMA4_REG = (u16)(dest); \
	HDMA5_REG = ((u16)(size)>>4) - 1;

#define ScrollerDone()	(scroll_text_ptr == 0)

//////////////////////////////////////////////////////////////////////////////
// variables                                                                //
//////////////////////////////////////////////////////////////////////////////
extern u8 fontOBJ0[];
extern u8 fontOBJ1[];
extern u8 oam_table[];
extern s8 stab[];
extern s8 ctab[];
extern u16 vbls;
extern u8 *scroll_text_ptr;
extern const u16 scroller_pals[];
extern u8 sync_flip;

//////////////////////////////////////////////////////////////////////////////
// prototypes                                                               //
//////////////////////////////////////////////////////////////////////////////
void RefreshOAM();
void clear_VBL_LCD();
//void clear_VBL();
//void clear_LCD();
void clear_TIM();
void Decompress(void* dest, void* src);
void Decompress2(void* dest, void* src);
void FadeInit(u16 *pal);
void Fade();
void ResetStuff();
void ClearMaps();
void DecompressBG(u8 *data);
void DecompressOBJ(u8 *data);
void LoadFontAsBackground();
void LoadFontAsSprites();
void SetScrollerText(const u8 *scroll_text);
void UpdateScroller();
void UpdateScroller2(u8 *oam_ptr, u8 oam_nr);




#endif	// _COMMON_H
