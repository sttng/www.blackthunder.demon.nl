//////////////////////////////////////////////////////////////////////////////
// main.c                                                                   //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include "common.h"
#include "asm.h"

//////////////////////////////////////////////////////////////////////////////
// typedefs                                                                 //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// variables                                                                //
//////////////////////////////////////////////////////////////////////////////
extern u8 oam1b[];
extern u8 oam2b[];

/*const static u16 testpal[] =
{
	RGB(0,0,0), RGB(9,9,9), RGB(20,20,20), RGB(31,31,31),
	
	RGB(0,0,0), RGB(31,0,0), RGB(0,31,0), RGB(0,0,31),
	RGB(0,0,0), RGB(31,0,0), RGB(0,31,0), RGB(0,0,31),
	RGB(0,0,0), RGB(31,0,0), RGB(0,31,0), RGB(0,0,31),
	RGB(0,0,0), RGB(31,0,0), RGB(0,31,0), RGB(0,0,31),
	RGB(0,0,0), RGB(31,0,0), RGB(0,31,0), RGB(0,0,31),
	RGB(0,0,0), RGB(31,0,0), RGB(0,31,0), RGB(0,0,31),
	RGB(0,0,0), RGB(31,0,0), RGB(0,31,0), RGB(0,0,31),
	RGB(0,0,0), RGB(31,0,0), RGB(0,31,0), RGB(0,0,31),
};*/

const static u8 scroll_text[] = "                    "
	"My intension was to make a good demo for a change, but you know... the deadline for GBdev 2000 is few hours away ;) "
	"Just converted some small MOD to lemon player format ^_^. Too bad my player data isn't small enough to fit in 32Kb. "
	"Nice fast optimized rotozoomer uh? Hope it doesn't affect this scoller. I wanted to add some more things and break some records, but time is spare."
	"                      ";


extern u16 out_gbp[];

extern u8 tilemap[32][32];
extern u8 attrmap[32][32];

extern u8 out_map[];		// pal[3] + index[2] per pixel
extern u8 bitmap_ram[];	// in RAM (decompressed)

u8 a;
s16 z;
u8 zooming;

//////////////////////////////////////////////////////////////////////////////
// Do                                                                       //
//////////////////////////////////////////////////////////////////////////////
void Do()
{
	long wc;	
	s = stab[a] * z;
	c = ctab[a] * z;
	wc = c*-20;
	s_ox = s_oy = s*-20;
	c_oy = +wc;
	c_ox = -wc;
	c = -c;
	SetRot();
	c = -c;
	mp = ((u8*)&tilemap);
	Do2_dest2();
	//frame++;
}

//////////////////////////////////////////////////////////////////////////////
// vbl_irq                                                                  //
//////////////////////////////////////////////////////////////////////////////
void RotoVbl()
{
	RefreshOAM();
	vbls++;
	SCX_REG = (vbls & 1) ? 1 : 255;
	SCY_REG = (vbls & 1) ? 255 : 1;

	if ((u8)vbls & 1)
	{ 
		a -= 1;
		
		OAM_SRC = (u16)oam1b>>8;

		if (zooming)
		{
			z -= 1;
			if (z <= 1) { z=1; zooming = 0; }
		}
		else
		{
			z += 1;
			if (z > 20) { z=20; zooming = 1; }
		}
			
		Do();
		
		VBK_REG=1; HDMA(attrmap, 0x9800, (u16)18*32);
	}
	else
	{
		OAM_SRC = (u16)oam2b>>8;
		
		VBK_REG=0; HDMA(tilemap, 0x9800, (u16)18*32);
	}

	//VBK_REG=1; GPDMA(attrmap, 0x9800, (u16)18*32);
	//VBK_REG=0; GPDMA(tilemap, 0x9800, (u16)18*32);


/*	if (busy)
	{
		busy = 0;
		VBK_REG=1; HDMA(attrmap, 0x9800, 18L*32);
	}
	
	if (frame != lastframe)
	{
		lastframe = frame;
		VBK_REG=0; HDMA(tilemap, 0x9800, 18L*32);
		busy = 1;
	}*/
}

//////////////////////////////////////////////////////////////////////////////
// RotoZoom_main                                                            //
//////////////////////////////////////////////////////////////////////////////
void RotoZoom_main()
{
	SVBK_REG = 1;
	Decompress(bitmap_ram, out_map);
		
	set_bkg_palette(0, 8, (u16*)out_gbp);

	LoadFontAsSprites();
	set_sprite_palette(0, 8, (u16*)scroller_pals); //sprite_pals);
	SetScrollerText(scroll_text);
	
	VBK_REG=0;
	memcpy(Do2_dest, Do2, Do2_end-Do2);		// SMC routine
	RotoTiles();
	add_VBL(RotoVbl);
	SHOW_SPRITES;
	DISPLAY_ON;


	while (!ScrollerDone())
	{
		UpdateScroller2(oam1b,0);
		UpdateScroller2(oam2b,1);
	}
}
