//////////////////////////////////////////////////////////////////////////////
// c2bin.cpp                                                                //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <process.h>

//////////////////////////////////////////////////////////////////////////////
// main                                                                     //
//////////////////////////////////////////////////////////////////////////////
int main(int argc, const char *argv[])
{
	if (argc < 2) { printf("Syntax: %s <lemonmusic.c>\n", argv[0]); return -1; }

	FILE *fi = fopen(argv[1], "rt");
	if (!fi) { printf("Error opening input file!\n"); return -1; }


	FILE *fo = 0;
	char filename[256];
	strcpy(filename, "mymusic0.bin");
	int words=0, fn='0';


	while (1)
	{
		char s[4096], *p;
		if (!fgets(s, sizeof(s), fi)) break;

		p = strchr(s, '\n');	// remove eol
		if (p) *p = 0;
		p = s;

		// start with "0x" ?
		if (s[0] == '0') if (s[1] == 'x')
		{
			if (!fo)
			{
				filename[7] = fn++;	// !!!
				fo = fopen(filename, "wb");
				if (!fo) { printf("Error opening output file!\n"); return -1; }
			}

			while (p)
			{
				unsigned int n = strtoul(p+2, 0, 16);
				fwrite(&n, 2, 1, fo);
				p = strchr(p, ',');
				if (p) { p++; if (!*p) p=0; }
				words++;
			}
		}

		if (words >= 2048)
		{
			words = 0;
			fclose(fo); fo = 0;
		}

		//spawnlp(P_WAIT, "PPIBM", "PPIBM.exe", "p", "-m2", filename, 0);

	}

	fclose(fi);
	if (fo) fclose(fo);
	return 0;
}
